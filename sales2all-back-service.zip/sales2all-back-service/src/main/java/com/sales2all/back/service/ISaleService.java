package com.sales2all.back.service;

import com.sales2all.back.data.domain.SaleBean;

/**
 * Created by Yahor_Fralou on 8/2/2016.
 */
public interface ISaleService extends IBaseService<SaleBean> {
}
